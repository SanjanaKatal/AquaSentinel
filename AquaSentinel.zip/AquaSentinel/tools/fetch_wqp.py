import urllib.request
import urllib.parse
import ssl
import sys
import os
import time

sys.stdout.reconfigure(line_buffering=True)

out_dir = r"C:\Users\Hp\.gemini\antigravity\scratch\AquaSentinel\data\raw"
os.makedirs(out_dir, exist_ok=True)
out_path = os.path.join(out_dir, "wqp_raw.csv")

params = [
    ('statecode', 'US:37'),
    ('characteristicName', 'pH'),
    ('characteristicName', 'Dissolved oxygen (DO)'),
    ('characteristicName', 'Turbidity'),
    ('characteristicName', 'Temperature, water'),
    ('characteristicName', 'Specific conductance'),
    ('startDateLo', '01-01-2023'),
    ('startDateHi', '12-31-2023'),
    ('mimeType', 'csv'),
    ('zip', 'no')
]
query_string = urllib.parse.urlencode(params)
url = f"https://www.waterqualitydata.us/data/Result/search?{query_string}"
print("Query URL:", url, flush=True)

ctx = ssl.create_default_context()
req = urllib.request.Request(url, headers={'User-Agent': 'AquaSentinel/1.0 (Research)'})

t0 = time.time()
try:
    with urllib.request.urlopen(req, context=ctx, timeout=90) as resp:
        print(f"Response status: {resp.status}", flush=True)
        headers = dict(resp.headers)
        total_results = headers.get('Total-Result-Count', 'unknown')
        print(f"Total results reported by WQP: {total_results}", flush=True)
        
        total_bytes = 0
        with open(out_path, 'wb') as f:
            while True:
                chunk = resp.read(64 * 1024)
                if not chunk:
                    break
                f.write(chunk)
                total_bytes += len(chunk)
                if total_bytes % (512 * 1024) == 0:
                    print(f"Downloaded {total_bytes // 1024} KB...", flush=True)
                    
        elapsed = time.time() - t0
        print(f"Download complete: {total_bytes:,} bytes in {elapsed:.1f}s saved to {out_path}", flush=True)
except Exception as e:
    print(f"Error downloading: {e}", flush=True)
    sys.exit(1)
