"""
AquaSentinel - Streamlit AppTest Smoke Tester
Tests that app.py initializes and all pages render without exceptions.
"""

import os
import sys
import tempfile
sys.stdout.reconfigure(line_buffering=True)
os.environ['MPLCONFIGDIR'] = tempfile.mkdtemp()

from streamlit.testing.v1 import AppTest

app_path = r"C:\Users\Hp\.gemini\antigravity\scratch\AquaSentinel\app.py"
print(f"Testing Streamlit App: {app_path}")

pages = [
    "1. Home / Overview",
    "2. Dataset Explorer",
    "3. Exploratory Data Analysis",
    "4. Water Quality Prediction",
    "5. Anomaly Detection Engine",
    "6. Model Benchmarking",
    "7. Explainable AI (SHAP)",
    "8. About & Limitations"
]

all_passed = True

for page in pages:
    print(f"\n--- Testing Page: {page} ---")
    try:
        at = AppTest.from_file(app_path, default_timeout=30)
        at.run()
        
        # Navigate to page via sidebar radio
        radios = at.sidebar.radio
        if radios:
            radios[0].set_value(page).run()
            
        # Check for unhandled exceptions
        if at.exception:
            print(f"FAILED on page '{page}': {len(at.exception)} exception(s) found!")
            for exc in at.exception:
                print(f"  Exception: {exc.message}")
            all_passed = False
        else:
            print(f"PASSED: '{page}' rendered cleanly with 0 exceptions.")
    except Exception as e:
        print(f"FAILED to test page '{page}': {e}")
        all_passed = False

if all_passed:
    print("\nALL 8 STREAMLIT PAGES RENDERED SUCCESSFULLY WITH ZERO EXCEPTIONS!")
    sys.exit(0)
else:
    print("\nSOME PAGES ENCOUNTERED EXCEPTIONS!")
    sys.exit(1)
