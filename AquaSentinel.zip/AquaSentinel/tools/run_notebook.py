"""
AquaSentinel - Notebook Runner
Executes AquaSentinel.ipynb end-to-end to verify that every cell executes cleanly.
"""

import os
import sys
import tempfile
import time

# Ensure writable matplotlib temp config dir
os.environ['MPLCONFIGDIR'] = tempfile.mkdtemp()

import nbformat
from nbconvert.preprocessors import ExecutePreprocessor

nb_path = r"C:\Users\Hp\.gemini\antigravity\scratch\AquaSentinel\AquaSentinel.ipynb"
base_dir = r"C:\Users\Hp\.gemini\antigravity\scratch\AquaSentinel"

print(f"Reading notebook from: {nb_path}")
with open(nb_path, 'r', encoding='utf-8') as f:
    nb = nbformat.read(f, as_version=4)

ep = ExecutePreprocessor(timeout=600, kernel_name='python3')

print("Starting end-to-end execution of AquaSentinel.ipynb...")
t0 = time.time()
try:
    ep.preprocess(nb, {'metadata': {'path': base_dir}})
    print(f"Notebook executed successfully in {time.time() - t0:.1f}s!")
    
    # Save executed notebook
    with open(nb_path, 'w', encoding='utf-8') as f:
        nbformat.write(nb, f)
    print("Saved executed notebook with outputs.")
except Exception as e:
    print(f"Execution failed: {e}")
    # Print error details from cells
    for i, cell in enumerate(nb.cells):
        if cell.cell_type == 'code':
            for out in cell.get('outputs', []):
                if out.output_type == 'error':
                    print(f"\n--- ERROR IN CELL {i} ---")
                    print(cell.source[:200])
                    print("\n".join(out.traceback))
    sys.exit(1)
