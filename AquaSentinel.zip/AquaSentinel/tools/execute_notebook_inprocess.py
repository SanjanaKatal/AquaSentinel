"""
AquaSentinel - In-Process Notebook Executor
Executes AquaSentinel.ipynb cells sequentially in a shared Python namespace,
captures stdout/stderr and matplotlib figures, generates all project artifacts,
and writes the populated notebook back to disk.
"""

import os
import sys
import io
import base64
import traceback
import contextlib
import tempfile

# Force non-interactive matplotlib backend and local temp config
os.environ['MPLCONFIGDIR'] = tempfile.mkdtemp()
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import nbformat

def execute_notebook(nb_path):
    print(f"Reading notebook: {nb_path}")
    with open(nb_path, 'r', encoding='utf-8') as f:
        nb = nbformat.read(f, as_version=4)

    base_dir = os.path.dirname(os.path.abspath(nb_path))
    os.chdir(base_dir)

    # Execution namespace
    namespace = {
        '__name__': '__main__',
        '__file__': nb_path,
        'IN_COLAB': False,
        'BASE_DIR': base_dir
    }

    print(f"Executing {len(nb.cells)} cells...")

    for i, cell in enumerate(nb.cells):
        if cell.cell_type != 'code':
            continue

        source = cell.source.strip()
        if not source:
            continue

        # Filter out bash magic commands for local execution
        clean_lines = []
        for line in source.splitlines():
            line_str = line.strip()
            if line_str.startswith('!') or line_str.startswith('%'):
                # In Colab these are shell commands; locally skip or comment
                clean_lines.append(f"# {line}")
            else:
                clean_lines.append(line)
        exec_code = "\n".join(clean_lines)

        stdout_buf = io.StringIO()
        stderr_buf = io.StringIO()

        print(f"\n--- Executing Cell {i} ---")
        first_line = [l for l in clean_lines if l and not l.startswith('#')]
        if first_line:
            print(f"First line: {first_line[0][:80]}")

        cell.outputs = []
        has_error = False

        try:
            with contextlib.redirect_stdout(stdout_buf), contextlib.redirect_stderr(stderr_buf):
                exec(exec_code, namespace)
        except Exception as e:
            has_error = True
            tb_str = traceback.format_exc()
            print(f"ERROR in cell {i}: {e}")
            print(tb_str)
            cell.outputs.append(nbformat.v4.new_output(
                output_type='error',
                ename=type(e).__name__,
                evalue=str(e),
                traceback=tb_str.splitlines()
            ))

        out_text = stdout_buf.getvalue()
        err_text = stderr_buf.getvalue()

        if out_text:
            print(out_text.strip()[:200])
            cell.outputs.append(nbformat.v4.new_output(
                output_type='stream',
                name='stdout',
                text=out_text
            ))

        if err_text:
            print(f"STDERR: {err_text.strip()[:200]}")
            cell.outputs.append(nbformat.v4.new_output(
                output_type='stream',
                name='stderr',
                text=err_text
            ))

        # Check for open matplotlib figures
        fig_nums = plt.get_fignums()
        for fnum in fig_nums:
            fig = plt.figure(fnum)
            buf = io.BytesIO()
            fig.savefig(buf, format='png', bbox_inches='tight', dpi=150)
            buf.seek(0)
            img_b64 = base64.b64encode(buf.read()).decode('utf-8')
            cell.outputs.append(nbformat.v4.new_output(
                output_type='display_data',
                data={'image/png': img_b64, 'text/plain': '<Figure size ...>'}
            ))
        plt.close('all')

        cell.execution_count = i + 1

        if has_error:
            print(f"Stopping execution due to error in cell {i}.")
            sys.exit(1)

    # Save executed notebook
    with open(nb_path, 'w', encoding='utf-8') as f:
        nbformat.write(nb, f)
    print(f"\nAll cells executed successfully! Populated notebook saved to {nb_path}")

if __name__ == '__main__':
    nb_file = os.path.join(r"C:\Users\Hp\.gemini\antigravity\scratch\AquaSentinel", "AquaSentinel.ipynb")
    execute_notebook(nb_file)
