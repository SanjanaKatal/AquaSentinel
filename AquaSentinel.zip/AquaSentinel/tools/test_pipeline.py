import os
import tempfile
os.environ['MPLCONFIGDIR'] = tempfile.mkdtemp()

import numpy as np
import pandas as pd
import shap
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.metrics import classification_report, accuracy_score
from xgboost import XGBClassifier

raw_path = r"C:\Users\Hp\.gemini\antigravity\scratch\AquaSentinel\data\raw\wqp_raw.csv"
df = pd.read_csv(raw_path, low_memory=False)

unit_col = 'ResultMeasure/MeasureUnitCode'
valid_do = (df['CharacteristicName'] != 'Dissolved oxygen (DO)') | (df[unit_col].str.lower() == 'mg/l')
valid_cond = (df['CharacteristicName'] != 'Specific conductance') | (df[unit_col].str.contains('uS/cm|µS/cm', case=False, na=False))
df = df[valid_do & valid_cond].copy()
df['ResultMeasureValue'] = pd.to_numeric(df['ResultMeasureValue'], errors='coerce')
df = df.dropna(subset=['ResultMeasureValue'])

char_map = {
    'pH': 'pH',
    'Dissolved oxygen (DO)': 'DissolvedOxygen_mgL',
    'Turbidity': 'Turbidity_NTU',
    'Temperature, water': 'Temperature_C',
    'Specific conductance': 'SpecificConductance_uScm'
}
df['Param'] = df['CharacteristicName'].map(char_map)
df = df.dropna(subset=['Param'])

df['ActivityTime'] = df['ActivityStartTime/Time'].fillna('00:00:00')
df['SampleKey'] = (
    df['MonitoringLocationIdentifier'].astype(str) + "_" +
    df['ActivityStartDate'].astype(str) + "_" +
    df['ActivityTime'].astype(str)
)

pivoted = df.pivot_table(
    index=['SampleKey', 'MonitoringLocationIdentifier', 'ActivityStartDate', 'ActivityTime'],
    columns='Param',
    values='ResultMeasureValue',
    aggfunc='mean'
).reset_index()

target_params = ['pH', 'DissolvedOxygen_mgL', 'Turbidity_NTU', 'Temperature_C', 'SpecificConductance_uScm']
complete = pivoted.dropna(subset=target_params).copy()
valid_bounds = (
    (complete['pH'] >= 0) & (complete['pH'] <= 14) &
    (complete['DissolvedOxygen_mgL'] >= 0) & (complete['DissolvedOxygen_mgL'] <= 25) &
    (complete['Turbidity_NTU'] >= 0) & (complete['Turbidity_NTU'] <= 2000) &
    (complete['Temperature_C'] >= -2) & (complete['Temperature_C'] <= 45) &
    (complete['SpecificConductance_uScm'] >= 0) & (complete['SpecificConductance_uScm'] <= 50000)
)
complete = complete[valid_bounds].copy()

def assign_label(row):
    is_poor = (
        (row['pH'] < 6.0) or (row['pH'] > 9.0) or
        (row['DissolvedOxygen_mgL'] < 4.5) or
        (row['Turbidity_NTU'] > 30.0) or
        (row['SpecificConductance_uScm'] > 800.0) or
        (row['Temperature_C'] > 28.0)
    )
    if is_poor:
        return 'Poor'
    is_moderate = (
        (row['pH'] < 6.5) or (row['pH'] > 8.5) or
        (row['DissolvedOxygen_mgL'] < 6.5) or
        (row['Turbidity_NTU'] > 10.0) or
        (row['SpecificConductance_uScm'] > 250.0) or
        (row['Temperature_C'] > 22.0)
    )
    if is_moderate:
        return 'Moderate'
    return 'Good'

complete['Quality_Class'] = complete.apply(assign_label, axis=1)

# Explicitly convert to pure numpy contiguous arrays
X = np.ascontiguousarray(complete[target_params].to_numpy(dtype=np.float64))
y = np.array(complete['Quality_Class'].tolist(), dtype=object)

print("X type:", type(X), X.shape, X.dtype)
print("y type:", type(y), y.shape, y.dtype)

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
print("Train size:", len(X_train), "Test size:", len(X_test))

# Test Random Forest Pipeline
rf_pipe = Pipeline([
    ('scaler', StandardScaler()),
    ('classifier', RandomForestClassifier(n_estimators=50, random_state=42, class_weight='balanced'))
])
rf_pipe.fit(X_train, y_train)
y_pred = rf_pipe.predict(X_test)
print("RF Test Accuracy:", accuracy_score(y_test, y_pred))

# Test SHAP on RF
scaler = rf_pipe.named_steps['scaler']
rf_clf = rf_pipe.named_steps['classifier']
X_test_scaled = scaler.transform(X_test[:50])

explainer = shap.TreeExplainer(rf_clf)
shap_values = explainer.shap_values(X_test_scaled)
print("SHAP TreeExplainer succeeded. Type:", type(shap_values))
if isinstance(shap_values, list):
    print("SHAP values list length:", len(shap_values), "Shape 0:", shap_values[0].shape)
elif hasattr(shap_values, 'shape'):
    print("SHAP values shape:", shap_values.shape)

# Test XGBoost Pipeline
label_to_idx = {'Good': 0, 'Moderate': 1, 'Poor': 2}
idx_to_label = {0: 'Good', 1: 'Moderate', 2: 'Poor'}
y_train_num = np.array([label_to_idx[l] for l in y_train], dtype=np.int32)
y_test_num = np.array([label_to_idx[l] for l in y_test], dtype=np.int32)

xgb_pipe = Pipeline([
    ('scaler', StandardScaler()),
    ('classifier', XGBClassifier(n_estimators=50, max_depth=4, learning_rate=0.1, random_state=42, eval_metric='mlogloss'))
])
xgb_pipe.fit(X_train, y_train_num)
y_xgb_pred = xgb_pipe.predict(X_test)
print("XGBoost Test Accuracy:", accuracy_score(y_test_num, y_xgb_pred))

# Test Isolation Forest
iso = Pipeline([
    ('scaler', StandardScaler()),
    ('classifier', IsolationForest(contamination=0.05, random_state=42))
])
iso.fit(X_train)
iso_preds = iso.predict(X_test)
print("Isolation Forest anomalies in test set:", (iso_preds == -1).sum())

print("ALL PIPELINE TESTS PASSED CLEANLY!")
