import pandas as pd
import numpy as np

# Load the test_clean output
# Let's inspect class distributions with regulatory thresholds
raw_path = r"C:\Users\Hp\.gemini\antigravity\scratch\AquaSentinel\data\raw\wqp_raw.csv"
df = pd.read_csv(raw_path, low_memory=False)

unit_col = 'ResultMeasure/MeasureUnitCode'
do_mask = df['CharacteristicName'] == 'Dissolved oxygen (DO)'
cond_mask = df['CharacteristicName'] == 'Specific conductance'
valid_do = (~do_mask) | (df[unit_col].str.lower() == 'mg/l')
valid_cond = (~cond_mask) | (df[unit_col].str.contains('uS/cm|µS/cm', case=False, na=False))

df_filtered = df[valid_do & valid_cond].copy()
df_filtered['ResultMeasureValue'] = pd.to_numeric(df_filtered['ResultMeasureValue'], errors='coerce')
df_filtered = df_filtered.dropna(subset=['ResultMeasureValue'])

char_map = {
    'pH': 'pH',
    'Dissolved oxygen (DO)': 'DissolvedOxygen_mgL',
    'Turbidity': 'Turbidity_NTU',
    'Temperature, water': 'Temperature_C',
    'Specific conductance': 'SpecificConductance_uScm'
}
df_filtered['Param'] = df_filtered['CharacteristicName'].map(char_map)
df_filtered = df_filtered.dropna(subset=['Param'])

df_filtered['ActivityTime'] = df_filtered['ActivityStartTime/Time'].fillna('00:00:00')
df_filtered['SampleKey'] = (
    df_filtered['MonitoringLocationIdentifier'].astype(str) + "_" +
    df_filtered['ActivityStartDate'].astype(str) + "_" +
    df_filtered['ActivityTime'].astype(str)
)

pivoted = df_filtered.pivot_table(
    index=['SampleKey', 'MonitoringLocationIdentifier', 'ActivityStartDate', 'ActivityTime'],
    columns='Param',
    values='ResultMeasureValue',
    aggfunc='mean'
).reset_index()

target_params = ['pH', 'DissolvedOxygen_mgL', 'Turbidity_NTU', 'Temperature_C', 'SpecificConductance_uScm']
complete = pivoted.dropna(subset=target_params).copy()
valid_bounds = (
    (complete['pH'] >= 0) & (complete['pH'] <= 14) &
    (complete['DissolvedOxygen_mgL'] >= 0) & (complete['DissolvedOxygen_mgL'] <= 25) &
    (complete['Turbidity_NTU'] >= 0) & (complete['Turbidity_NTU'] <= 2000) &
    (complete['Temperature_C'] >= -2) & (complete['Temperature_C'] <= 45) &
    (complete['SpecificConductance_uScm'] >= 0) & (complete['SpecificConductance_uScm'] <= 50000)
)
complete = complete[valid_bounds].copy()

# Let's test a standards-based multi-tier water quality index rule
# WHO / US EPA Freshwater standard:
# 1. pH: Good: 6.5 - 8.5; Moderate: 6.0 - 6.5 or 8.5 - 9.0; Poor: <6.0 or >9.0
# 2. DO: Good: >= 6.5; Moderate: 4.5 - 6.5; Poor: < 4.5
# 3. Turbidity: Good: <= 10 NTU; Moderate: 10 - 30 NTU; Poor: > 30 NTU
# 4. Specific Conductance: Good: <= 250 uS/cm; Moderate: 250 - 800 uS/cm; Poor: > 800 uS/cm
# 5. Temperature: Good: <= 22 C; Moderate: 22 - 28 C; Poor: > 28 C

def assign_label(row):
    # Check for Poor criteria (any severe impairment)
    is_poor = (
        (row['pH'] < 6.0) or (row['pH'] > 9.0) or
        (row['DissolvedOxygen_mgL'] < 4.5) or
        (row['Turbidity_NTU'] > 30.0) or
        (row['SpecificConductance_uScm'] > 800.0) or
        (row['Temperature_C'] > 28.0)
    )
    if is_poor:
        return 'Poor'
    
    # Check for Moderate criteria (mild departure from pristine)
    is_moderate = (
        (row['pH'] < 6.5) or (row['pH'] > 8.5) or
        (row['DissolvedOxygen_mgL'] < 6.5) or
        (row['Turbidity_NTU'] > 10.0) or
        (row['SpecificConductance_uScm'] > 250.0) or
        (row['Temperature_C'] > 22.0)
    )
    if is_moderate:
        return 'Moderate'
    
    return 'Good'

complete['Quality_Class'] = complete.apply(assign_label, axis=1)
counts = complete['Quality_Class'].value_counts()
print("Class counts:")
print(counts)
print("\nClass percentages:")
print((counts / len(complete) * 100).round(2))
