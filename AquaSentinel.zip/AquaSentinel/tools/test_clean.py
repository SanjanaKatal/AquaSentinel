import pandas as pd
import numpy as np
import os

raw_path = r"C:\Users\Hp\.gemini\antigravity\scratch\AquaSentinel\data\raw\wqp_raw.csv"
df = pd.read_csv(raw_path, low_memory=False)
print("Raw rows:", len(df))
print("Unique characteristics:", df['CharacteristicName'].value_counts().to_dict())

# 1. Unit Standardization and filtering
# Check units
unit_col = 'ResultMeasure/MeasureUnitCode'

# Turbidity
turb_mask = df['CharacteristicName'] == 'Turbidity'
print("Turbidity units:", df[turb_mask][unit_col].value_counts(dropna=False).to_dict())

# DO
do_mask = df['CharacteristicName'] == 'Dissolved oxygen (DO)'
print("DO units:", df[do_mask][unit_col].value_counts(dropna=False).to_dict())

# Specific conductance
cond_mask = df['CharacteristicName'] == 'Specific conductance'
print("Conductance units:", df[cond_mask][unit_col].value_counts(dropna=False).to_dict())

# Temperature
temp_mask = df['CharacteristicName'] == 'Temperature, water'
print("Temp units:", df[temp_mask][unit_col].value_counts(dropna=False).to_dict())

# Filter valid units:
# DO: keep mg/L
valid_do = (~do_mask) | (df[unit_col].str.lower() == 'mg/l')
# Conductance: keep uS/cm
valid_cond = (~cond_mask) | (df[unit_col].str.contains('uS/cm|µS/cm', case=False, na=False))
# Temp: keep deg C or convert deg F
# Let's inspect if any deg F exist
f_mask = temp_mask & (df[unit_col].str.lower().isin(['deg f', 'f']))
print("Temp deg F count:", f_mask.sum())

df_filtered = df[valid_do & valid_cond].copy()
print("After unit filtering, rows:", len(df_filtered))

# Convert values to numeric
df_filtered['ResultMeasureValue'] = pd.to_numeric(df_filtered['ResultMeasureValue'], errors='coerce')
df_filtered = df_filtered.dropna(subset=['ResultMeasureValue'])

# Map characteristics
char_map = {
    'pH': 'pH',
    'Dissolved oxygen (DO)': 'DissolvedOxygen_mgL',
    'Turbidity': 'Turbidity_NTU',
    'Temperature, water': 'Temperature_C',
    'Specific conductance': 'SpecificConductance_uScm'
}
df_filtered['Param'] = df_filtered['CharacteristicName'].map(char_map)
df_filtered = df_filtered.dropna(subset=['Param'])

# Identify physical sample event
df_filtered['ActivityTime'] = df_filtered['ActivityStartTime/Time'].fillna('00:00:00')
# Create unique key
df_filtered['SampleKey'] = (
    df_filtered['MonitoringLocationIdentifier'].astype(str) + "_" +
    df_filtered['ActivityStartDate'].astype(str) + "_" +
    df_filtered['ActivityTime'].astype(str)
)

# Pivot: duplicate values in same event -> mean
pivoted = df_filtered.pivot_table(
    index=['SampleKey', 'MonitoringLocationIdentifier', 'ActivityStartDate', 'ActivityTime'],
    columns='Param',
    values='ResultMeasureValue',
    aggfunc='mean'
).reset_index()

print("Pivoted sample events:", len(pivoted))
target_params = ['pH', 'DissolvedOxygen_mgL', 'Turbidity_NTU', 'Temperature_C', 'SpecificConductance_uScm']
print("Missing percentage in pivoted:")
print((pivoted[target_params].isna().mean() * 100).round(2).to_dict())

# Complete cases
complete = pivoted.dropna(subset=target_params).copy()
print("Complete cases with all 5 parameters:", len(complete))

# Sanity checks / bounds
# pH: 0 to 14
# DO: 0 to 25 mg/L
# Turbidity: 0 to 1000 NTU
# Temp: -2 to 45 C
# Cond: 0 to 20000 uS/cm
valid_bounds = (
    (complete['pH'] >= 0) & (complete['pH'] <= 14) &
    (complete['DissolvedOxygen_mgL'] >= 0) & (complete['DissolvedOxygen_mgL'] <= 25) &
    (complete['Turbidity_NTU'] >= 0) & (complete['Turbidity_NTU'] <= 2000) &
    (complete['Temperature_C'] >= -2) & (complete['Temperature_C'] <= 45) &
    (complete['SpecificConductance_uScm'] >= 0) & (complete['SpecificConductance_uScm'] <= 50000)
)
print("Rows failing sanity bounds:", (~valid_bounds).sum())
complete = complete[valid_bounds]

print("Cleaned modeling records count:", len(complete))
print("Sample stations:", complete['MonitoringLocationIdentifier'].nunique())
print("Date span:", complete['ActivityStartDate'].min(), "to", complete['ActivityStartDate'].max())
print("\nFeature summary stats:")
print(complete[target_params].describe().round(2))
