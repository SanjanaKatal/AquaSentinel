"""
AquaSentinel - Module 4: Unsupervised Anomaly Detection
Fits an Isolation Forest pipeline and computes parameter-level robust Z-scores
to output automated, human-readable explanations for flagged observations.
"""

import os
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.ensemble import IsolationForest
from sklearn.decomposition import PCA
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "outputs", "cleaned_dataset.csv")
MODEL_OUT = os.path.join(BASE_DIR, "models", "isolation_forest.pkl")
CSV_OUT = os.path.join(BASE_DIR, "outputs", "anomaly_results.csv")
FIGS_DIR = os.path.join(BASE_DIR, "reports", "visualizations")

FEATURE_COLS = ['pH', 'DissolvedOxygen_mgL', 'Turbidity_NTU', 'Temperature_C', 'SpecificConductance_uScm']

def run():
    print("=" * 60)
    print(" AQUASENTINEL - MODULE 4: ANOMALY DETECTION ENGINE")
    print("=" * 60)

    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"Cleaned dataset not found at {DATA_PATH}. Run Module 1 first.")

    df = pd.read_csv(DATA_PATH)
    X = np.ascontiguousarray(df[FEATURE_COLS].to_numpy(dtype=np.float64))

    print("Fitting unsupervised Isolation Forest pipeline (5% contamination rate)...")
    iso_pipe = Pipeline([
        ('scaler', StandardScaler()),
        ('classifier', IsolationForest(contamination=0.05, random_state=42))
    ])
    iso_pipe.fit(X)

    # Predictions & anomaly scores
    df['Anomaly_Pred'] = iso_pipe.predict(X)
    df['Anomaly_Score'] = iso_pipe.named_steps['classifier'].score_samples(
        iso_pipe.named_steps['scaler'].transform(X)
    )
    df['Anomaly_Label'] = df['Anomaly_Pred'].map({1: 'Normal', -1: 'Anomaly'})

    # Robust Z-Scores for diagnostic explanations
    medians = df[FEATURE_COLS].median()
    iqrs = (df[FEATURE_COLS].quantile(0.75) - df[FEATURE_COLS].quantile(0.25)).replace(0, 1e-4)

    def explain_anomaly(row):
        if row['Anomaly_Label'] == 'Normal':
            return 'Standard physical profile within expected distribution.'
        reasons = []
        for col in FEATURE_COLS:
            z_rob = (row[col] - medians[col]) / (iqrs[col] / 1.349)
            if abs(z_rob) >= 2.5:
                direction = "Elevated" if z_rob > 0 else "Depressed"
                reasons.append(f"{direction} {col} (Z_rob = {z_rob:.1f})")
        return '; '.join(reasons) if reasons else 'Multivariate interaction anomaly across multiple parameters.'

    df['Anomaly_Reason'] = df.apply(explain_anomaly, axis=1)

    # Save
    os.makedirs(os.path.dirname(MODEL_OUT), exist_ok=True)
    os.makedirs(os.path.dirname(CSV_OUT), exist_ok=True)
    joblib.dump(iso_pipe, MODEL_OUT)
    df.to_csv(CSV_OUT, index=False)

    n_flagged = (df['Anomaly_Label'] == 'Anomaly').sum()
    print(f"Total flagged observations: {n_flagged:,} of {len(df):,} ({n_flagged/len(df)*100:.2f}%)")
    print(f"Saved Isolation Forest model to {MODEL_OUT}")
    print(f"Saved anomaly table with explanations to {CSV_OUT}")

    # PCA 2D projection plot
    print("Generating PCA 2D projection...")
    pca = PCA(n_components=2, random_state=42)
    X_scaled = iso_pipe.named_steps['scaler'].transform(X)
    X_pca = pca.fit_transform(X_scaled)

    os.makedirs(FIGS_DIR, exist_ok=True)
    plt.figure(figsize=(9, 6))
    sns.scatterplot(x=X_pca[:, 0], y=X_pca[:, 1], hue=df['Anomaly_Label'],
                    palette={'Normal': '#3AAFA9', 'Anomaly': '#C0392B'}, alpha=0.7, s=40)
    plt.title(f"PCA 2D Projection of Anomalies (Explained Var: {pca.explained_variance_ratio_.sum()*100:.1f}%)", fontweight='bold')
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.tight_layout()
    pca_out = os.path.join(FIGS_DIR, "anomaly_pca_projection.png")
    plt.savefig(pca_out, dpi=300)
    plt.close()
    print(f"  -> Saved {pca_out}")

    print("\nSample Flagged Anomalies:")
    for idx, r in df[df['Anomaly_Label'] == 'Anomaly'].head(3).iterrows():
        print(f"  Station {r['MonitoringLocationIdentifier']} ({r['ActivityStartDate']}): {r['Anomaly_Reason']}")
    print("=" * 60)

if __name__ == '__main__':
    run()
