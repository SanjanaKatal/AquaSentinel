"""
AquaSentinel - Module 1: Data Management & Preprocessing
Loads raw WQP data, cleans, standardizes units, pivots to sample events,
applies physical sanity bounds, and derives WHO/EPA regulatory quality labels.
"""

import os
import sys
import pandas as pd
import numpy as np

# Paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW_PATH = os.path.join(BASE_DIR, "data", "raw", "wqp_raw.csv")
OUT_CLEAN = os.path.join(BASE_DIR, "outputs", "cleaned_dataset.csv")
OUT_PROC = os.path.join(BASE_DIR, "data", "processed", "cleaned_water_quality.csv")

def run():
    print("=" * 60)
    print(" AQUASENTINEL - MODULE 1: DATA MANAGEMENT & PREPROCESSING")
    print("=" * 60)

    if not os.path.exists(RAW_PATH):
        print(f"Raw data not found at {RAW_PATH}.")
        print("Running fetcher...")
        from tools import fetch_wqp
        fetch_wqp.main()

    print(f"Loading raw WQP observations from: {RAW_PATH}")
    df_raw = pd.read_csv(RAW_PATH, low_memory=False)
    print(f"Raw dataset shape: {df_raw.shape[0]:,} rows x {df_raw.shape[1]} columns")

    # 1. Unit Standardization and Filtering
    unit_col = 'ResultMeasure/MeasureUnitCode'
    do_mask = df_raw['CharacteristicName'] == 'Dissolved oxygen (DO)'
    cond_mask = df_raw['CharacteristicName'] == 'Specific conductance'

    valid_do = (~do_mask) | (df_raw[unit_col].astype(str).str.lower() == 'mg/l')
    valid_cond = (~cond_mask) | (df_raw[unit_col].astype(str).str.contains('uS/cm|µS/cm', case=False, na=False))

    df_filtered = df_raw[valid_do & valid_cond].copy()
    print(f"Retained {len(df_filtered):,} rows after filtering units (DO in mg/L, Cond in uS/cm).")

    df_filtered['ResultMeasureValue'] = pd.to_numeric(df_filtered['ResultMeasureValue'], errors='coerce')
    df_filtered = df_filtered.dropna(subset=['ResultMeasureValue'])

    char_map = {
        'pH': 'pH',
        'Dissolved oxygen (DO)': 'DissolvedOxygen_mgL',
        'Turbidity': 'Turbidity_NTU',
        'Temperature, water': 'Temperature_C',
        'Specific conductance': 'SpecificConductance_uScm'
    }
    df_filtered['Param'] = df_filtered['CharacteristicName'].map(char_map)
    df_filtered = df_filtered.dropna(subset=['Param'])

    # 2. Key Alignment & Wide Pivoting
    df_filtered['ActivityTime'] = df_filtered['ActivityStartTime/Time'].fillna('00:00:00')
    df_filtered['SampleKey'] = (
        df_filtered['MonitoringLocationIdentifier'].astype(str) + "_" +
        df_filtered['ActivityStartDate'].astype(str) + "_" +
        df_filtered['ActivityTime'].astype(str)
    )

    print("Pivoting long-format records into physical sample events...")
    pivoted = df_filtered.pivot_table(
        index=['SampleKey', 'MonitoringLocationIdentifier', 'ActivityStartDate', 'ActivityTime'],
        columns='Param',
        values='ResultMeasureValue',
        aggfunc='mean'
    ).reset_index()

    FEATURE_COLS = ['pH', 'DissolvedOxygen_mgL', 'Turbidity_NTU', 'Temperature_C', 'SpecificConductance_uScm']
    complete_df = pivoted.dropna(subset=FEATURE_COLS).copy()
    print(f"Complete sampling events with all 5 parameters: {len(complete_df):,}")

    # 3. Physical Sanity Bounds
    valid_bounds = (
        (complete_df['pH'] >= 0.0) & (complete_df['pH'] <= 14.0) &
        (complete_df['DissolvedOxygen_mgL'] >= 0.0) & (complete_df['DissolvedOxygen_mgL'] <= 25.0) &
        (complete_df['Turbidity_NTU'] >= 0.0) & (complete_df['Turbidity_NTU'] <= 2000.0) &
        (complete_df['Temperature_C'] >= -2.0) & (complete_df['Temperature_C'] <= 45.0) &
        (complete_df['SpecificConductance_uScm'] >= 0.0) & (complete_df['SpecificConductance_uScm'] <= 50000.0)
    )
    cleaned_df = complete_df[valid_bounds].copy()
    print(f"Final cleaned modeling observations: {len(cleaned_df):,} across {cleaned_df['MonitoringLocationIdentifier'].nunique()} stations.")

    # 4. Standards-Based Derived Labeling (WHO / US EPA)
    def assign_tier(row):
        # Poor
        if (row['pH'] < 6.0 or row['pH'] > 9.0 or
            row['DissolvedOxygen_mgL'] < 4.5 or
            row['Turbidity_NTU'] > 30.0 or
            row['SpecificConductance_uScm'] > 800.0 or
            row['Temperature_C'] > 28.0):
            return 'Poor'
        # Moderate
        if (row['pH'] < 6.5 or row['pH'] > 8.5 or
            row['DissolvedOxygen_mgL'] < 6.5 or
            row['Turbidity_NTU'] > 10.0 or
            row['SpecificConductance_uScm'] > 250.0 or
            row['Temperature_C'] > 22.0):
            return 'Moderate'
        return 'Good'

    cleaned_df['Quality_Class'] = cleaned_df.apply(assign_tier, axis=1)

    print("\nClass Distribution:")
    for cls, cnt in cleaned_df['Quality_Class'].value_counts().items():
        print(f"  {cls:<10}: {cnt:>5} records ({cnt/len(cleaned_df)*100:.2f}%)")

    # Save
    os.makedirs(os.path.dirname(OUT_CLEAN), exist_ok=True)
    os.makedirs(os.path.dirname(OUT_PROC), exist_ok=True)
    cleaned_df.to_csv(OUT_CLEAN, index=False)
    cleaned_df.to_csv(OUT_PROC, index=False)
    print(f"\nOutputs saved successfully to:\n  - {OUT_CLEAN}\n  - {OUT_PROC}")
    print("=" * 60)

if __name__ == '__main__':
    run()
