"""
AquaSentinel - Module 6: Streamlit Decision-Support Dashboard Launcher
Launches app.py on port 8501.
"""

import os
import sys
import subprocess

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP_PATH = os.path.join(BASE_DIR, "app.py")

def run():
    print("=" * 60)
    print(" AQUASENTINEL - MODULE 6: STREAMLIT DASHBOARD")
    print("=" * 60)
    print(f"Target App: {APP_PATH}")
    print("Launching Streamlit dashboard on http://localhost:8501 ...")
    print("Press Ctrl+C to terminate the dashboard server.")
    subprocess.run([sys.executable, "-m", "streamlit", "run", APP_PATH, "--server.port", "8501"])

if __name__ == '__main__':
    run()
