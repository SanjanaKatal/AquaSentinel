"""
AquaSentinel - Module 3: Predictive Modeling & Benchmarking
Trains Logistic Regression, Random Forest, and XGBoost with zero data leakage.
Computes evaluation metrics and exports trained models.
"""

import os
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, GroupShuffleSplit
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from xgboost import XGBClassifier

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "outputs", "cleaned_dataset.csv")
MODELS_DIR = os.path.join(BASE_DIR, "models")
REPORTS_DIR = os.path.join(BASE_DIR, "reports", "model_results")
FIGS_DIR = os.path.join(BASE_DIR, "reports", "visualizations")

FEATURE_COLS = ['pH', 'DissolvedOxygen_mgL', 'Turbidity_NTU', 'Temperature_C', 'SpecificConductance_uScm']

def run():
    print("=" * 60)
    print(" AQUASENTINEL - MODULE 3: PREDICTIVE MODELING")
    print("=" * 60)

    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"Cleaned dataset not found at {DATA_PATH}. Run Module 1 first.")

    df = pd.read_csv(DATA_PATH)
    X = np.ascontiguousarray(df[FEATURE_COLS].to_numpy(dtype=np.float64))
    y = np.array(df['Quality_Class'].tolist(), dtype=object)

    # Stratified 80:20 Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    print(f"Dataset split: {len(X_train):,} Train samples, {len(X_test):,} Test samples")

    label_to_idx = {'Good': 0, 'Moderate': 1, 'Poor': 2}
    idx_to_label = {0: 'Good', 1: 'Moderate', 2: 'Poor'}
    y_train_num = np.array([label_to_idx[v] for v in y_train], dtype=np.int32)
    y_test_num = np.array([label_to_idx[v] for v in y_test], dtype=np.int32)

    pipelines = {
        'Logistic Regression': Pipeline([
            ('scaler', StandardScaler()),
            ('classifier', LogisticRegression(max_iter=1000, class_weight='balanced', random_state=42))
        ]),
        'Random Forest': Pipeline([
            ('scaler', StandardScaler()),
            ('classifier', RandomForestClassifier(n_estimators=150, max_depth=10, class_weight='balanced', random_state=42))
        ]),
        'XGBoost': Pipeline([
            ('scaler', StandardScaler()),
            ('classifier', XGBClassifier(n_estimators=150, max_depth=5, learning_rate=0.08, eval_metric='mlogloss', random_state=42))
        ])
    }

    results = {}
    os.makedirs(MODELS_DIR, exist_ok=True)
    os.makedirs(REPORTS_DIR, exist_ok=True)

    print("\nTraining and evaluating models on held-out test data...")
    for name, pipe in pipelines.items():
        if name == 'XGBoost':
            pipe.fit(X_train, y_train_num)
            y_pred_num = pipe.predict(X_test)
            y_pred = np.array([idx_to_label[v] for v in y_pred_num])
        else:
            pipe.fit(X_train, y_train)
            y_pred = pipe.predict(X_test)

        acc = accuracy_score(y_test, y_pred)
        p_macro = precision_score(y_test, y_pred, average='macro', zero_division=0)
        r_macro = recall_score(y_test, y_pred, average='macro', zero_division=0)
        f1_macro = f1_score(y_test, y_pred, average='macro', zero_division=0)
        recalls = recall_score(y_test, y_pred, average=None, labels=['Good', 'Moderate', 'Poor'], zero_division=0)

        results[name] = {
            'accuracy': float(acc),
            'macro_precision': float(p_macro),
            'macro_recall': float(r_macro),
            'macro_f1': float(f1_macro),
            'poor_recall': float(recalls[2]),
            'class_recall': {'Good': float(recalls[0]), 'Moderate': float(recalls[1]), 'Poor': float(recalls[2])}
        }

        # Save model
        clean_name = name.lower().replace(" ", "_")
        fname = f"{clean_name}.pkl" if "xgboost" not in clean_name else "xgboost_model.pkl"
        mpath = os.path.join(MODELS_DIR, fname)
        joblib.dump(pipe, mpath)

        print(f"\n--- {name} ---")
        print(f"  Accuracy       : {acc*100:.2f}%")
        print(f"  Macro F1       : {f1_macro:.4f}")
        print(f"  Poor-Tier Recall: {recalls[2]*100:.2f}%")
        print(f"  Saved model -> {mpath}")

    # Save metrics JSON & CSV
    json_path = os.path.join(REPORTS_DIR, "metrics_comparison.json")
    with open(json_path, 'w') as f:
        json.dump(results, f, indent=4)

    metrics_df = pd.DataFrame([
        {'Model': k, 'Accuracy': v['accuracy'], 'Macro_Precision': v['macro_precision'],
         'Macro_Recall': v['macro_recall'], 'Macro_F1': v['macro_f1'], 'Poor_Class_Recall': v['poor_recall']}
        for k, v in results.items()
    ])
    csv_path = os.path.join(REPORTS_DIR, "metrics_comparison.csv")
    metrics_df.to_csv(csv_path, index=False)
    print(f"\nSaved benchmark metrics to:\n  - {json_path}\n  - {csv_path}")

    # Non-Circularity Experiments
    print("\nRunning Methodological Non-Circularity Stress Tests:")
    groups = df['MonitoringLocationIdentifier'].values
    gss = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
    train_idx, test_idx = next(gss.split(X, y, groups=groups))
    rf_grp = Pipeline([
        ('scaler', StandardScaler()),
        ('classifier', RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced'))
    ])
    rf_grp.fit(X[train_idx], y[train_idx])
    grp_acc = accuracy_score(y[test_idx], rf_grp.predict(X[test_idx]))
    print(f"  1. Held-Out Station Generalization (Unseen Basins): {grp_acc*100:.2f}% Accuracy")

    X_no_do = np.ascontiguousarray(df[['pH', 'Turbidity_NTU', 'Temperature_C', 'SpecificConductance_uScm']].to_numpy(dtype=np.float64))
    X_tr_ndo, X_te_ndo, y_tr_ndo, y_te_ndo = train_test_split(X_no_do, y, test_size=0.2, random_state=42, stratify=y)
    rf_ndo = Pipeline([
        ('scaler', StandardScaler()),
        ('classifier', RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced'))
    ])
    rf_ndo.fit(X_tr_ndo, y_tr_ndo)
    surr_acc = accuracy_score(y_te_ndo, rf_ndo.predict(X_te_ndo))
    print(f"  2. Reduced-Feature Surrogate Test (Without DO): {surr_acc*100:.2f}% Accuracy")
    print("=" * 60)

if __name__ == '__main__':
    run()
