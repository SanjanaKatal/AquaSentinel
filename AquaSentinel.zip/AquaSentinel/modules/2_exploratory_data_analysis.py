"""
AquaSentinel - Module 2: Exploratory Data Analysis & Statistical Limnology
Generates histograms, boxplots, correlation heatmaps, and Henry's law regression.
"""

import os
import tempfile
os.environ['MPLCONFIGDIR'] = tempfile.mkdtemp()
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "outputs", "cleaned_dataset.csv")
FIGS_DIR = os.path.join(BASE_DIR, "reports", "visualizations")

FEATURE_COLS = ['pH', 'DissolvedOxygen_mgL', 'Turbidity_NTU', 'Temperature_C', 'SpecificConductance_uScm']
TIER_PALETTE = {'Good': '#27AE60', 'Moderate': '#F39C12', 'Poor': '#C0392B'}

def run():
    print("=" * 60)
    print(" AQUASENTINEL - MODULE 2: EXPLORATORY DATA ANALYSIS")
    print("=" * 60)

    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"Cleaned dataset not found at {DATA_PATH}. Run Module 1 first.")

    df = pd.read_csv(DATA_PATH)
    os.makedirs(FIGS_DIR, exist_ok=True)
    sns.set_theme(style="whitegrid", palette="muted")

    # 1. Parameter Histograms
    print("Generating parameter distribution histograms...")
    fig, axes = plt.subplots(2, 3, figsize=(15, 9))
    axes = axes.flatten()
    for i, col in enumerate(FEATURE_COLS):
        sns.histplot(df[col], kde=True, ax=axes[i], color='#007A78')
        axes[i].set_title(f"Distribution: {col}", fontweight='bold')
    axes[5].set_visible(False)
    plt.tight_layout()
    hist_out = os.path.join(FIGS_DIR, "parameter_distributions.png")
    plt.savefig(hist_out, dpi=300)
    plt.close()
    print(f"  -> Saved {hist_out}")

    # 2. Boxplots by Tier
    print("Generating parameter boxplots by quality tier...")
    fig, axes = plt.subplots(2, 3, figsize=(15, 9))
    axes = axes.flatten()
    for i, col in enumerate(FEATURE_COLS):
        sns.boxplot(data=df, x='Quality_Class', y=col, order=['Good', 'Moderate', 'Poor'],
                    hue='Quality_Class', palette=TIER_PALETTE, legend=False, ax=axes[i])
        axes[i].set_title(f"{col} Across Tiers", fontweight='bold')
    axes[5].set_visible(False)
    plt.tight_layout()
    box_out = os.path.join(FIGS_DIR, "parameter_boxplots.png")
    plt.savefig(box_out, dpi=300)
    plt.close()
    print(f"  -> Saved {box_out}")

    # 3. Correlation Heatmap
    print("Generating correlation matrix...")
    plt.figure(figsize=(8, 6))
    corr = df[FEATURE_COLS].corr()
    sns.heatmap(corr, annot=True, cmap="mako", fmt=".3f", cbar_kws={'label': 'Pearson Correlation'})
    plt.title("Pearson Correlation Matrix (5 Physicochemical Parameters)", fontweight='bold', pad=15)
    plt.tight_layout()
    corr_out = os.path.join(FIGS_DIR, "correlation_heatmap.png")
    plt.savefig(corr_out, dpi=300)
    plt.close()
    print(f"  -> Saved {corr_out}")

    # 4. Limnological DO vs Temperature Regression
    print("Generating DO vs Temperature regression (Henry's Law validation)...")
    plt.figure(figsize=(9, 6))
    sns.scatterplot(data=df, x='Temperature_C', y='DissolvedOxygen_mgL',
                    hue='Quality_Class', palette=TIER_PALETTE, alpha=0.7, s=40)
    sns.regplot(data=df, x='Temperature_C', y='DissolvedOxygen_mgL', scatter=False,
                color='black', line_kws={'linestyle': '--', 'linewidth': 2})
    r_val = df['Temperature_C'].corr(df['DissolvedOxygen_mgL'])
    plt.title(f"Limnological Dynamic: Dissolved Oxygen vs. Water Temp (r = {r_val:.3f})", fontweight='bold', pad=15)
    plt.tight_layout()
    do_out = os.path.join(FIGS_DIR, "do_vs_temperature.png")
    plt.savefig(do_out, dpi=300)
    plt.close()
    print(f"  -> Saved {do_out}")
    print(f"Limnological Interpretation: Strong negative correlation (r = {r_val:.3f}) confirms gas solubility physics.")
    print("=" * 60)

if __name__ == '__main__':
    run()
