"""
AquaSentinel - Module 5: Explainable AI (XAI)
Computes Permutation Feature Importance, SHAP TreeExplainer attributions,
and demonstrates a human-readable prediction explanation function.
"""

import os
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.inspection import permutation_importance
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import shap

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "outputs", "cleaned_dataset.csv")
MODEL_PATH = os.path.join(BASE_DIR, "models", "random_forest.pkl")
FIGS_DIR = os.path.join(BASE_DIR, "reports", "visualizations")

FEATURE_COLS = ['pH', 'DissolvedOxygen_mgL', 'Turbidity_NTU', 'Temperature_C', 'SpecificConductance_uScm']

def run():
    print("=" * 60)
    print(" AQUASENTINEL - MODULE 5: EXPLAINABLE AI (SHAP & PERMUTATION)")
    print("=" * 60)

    if not os.path.exists(DATA_PATH) or not os.path.exists(MODEL_PATH):
        raise FileNotFoundError("Cleaned dataset or Random Forest model not found. Run Modules 1 & 3 first.")

    df = pd.read_csv(DATA_PATH)
    rf_pipe = joblib.load(MODEL_PATH)

    X = np.ascontiguousarray(df[FEATURE_COLS].to_numpy(dtype=np.float64))
    y = np.array(df['Quality_Class'].tolist(), dtype=object)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    os.makedirs(FIGS_DIR, exist_ok=True)

    # 1. Permutation Importance on Test Set
    print("Computing Permutation Feature Importance on held-out test data...")
    perm_res = permutation_importance(rf_pipe, X_test, y_test, n_repeats=10, random_state=42, scoring='f1_macro')
    perm_df = pd.DataFrame({
        'Feature': FEATURE_COLS,
        'Importance_Mean': perm_res.importances_mean,
        'Importance_Std': perm_res.importances_std
    }).sort_values(by='Importance_Mean', ascending=True)

    plt.figure(figsize=(8, 4.5))
    plt.barh(perm_df['Feature'], perm_df['Importance_Mean'], xerr=perm_df['Importance_Std'], color='#007A78', alpha=0.85)
    plt.title("Permutation Feature Importance on Held-Out Test Set (Macro F1)", fontweight='bold', pad=12)
    plt.xlabel("Mean F1 Decrease When Feature Is Shuffled")
    plt.tight_layout()
    perm_out = os.path.join(FIGS_DIR, "permutation_importance.png")
    plt.savefig(perm_out, dpi=300)
    plt.close()
    print(f"  -> Saved {perm_out}")

    # 2. SHAP TreeExplainer
    print("Computing SHAP TreeExplainer attributions...")
    rf_clf = rf_pipe.named_steps['classifier']
    scaler = rf_pipe.named_steps['scaler']
    X_sample = X_test[:100]
    X_sample_scaled = scaler.transform(X_sample)

    explainer = shap.TreeExplainer(rf_clf)
    shap_vals = explainer.shap_values(X_sample_scaled)

    plt.figure(figsize=(9, 6))
    if isinstance(shap_vals, np.ndarray) and len(shap_vals.shape) == 3:
        shap.summary_plot(shap_vals[:, :, 2], X_sample_scaled, feature_names=FEATURE_COLS, show=False)
    elif isinstance(shap_vals, list):
        shap.summary_plot(shap_vals[2], X_sample_scaled, feature_names=FEATURE_COLS, show=False)
    plt.title("SHAP Global Feature Attribution (Impact on 'Poor' Quality Classification)", fontweight='bold', pad=15)
    plt.tight_layout()
    shap_out = os.path.join(FIGS_DIR, "shap_summary.png")
    plt.savefig(shap_out, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  -> Saved {shap_out}")

    # 3. Plain-Language Explanation Function Demonstration
    def explain_prediction(sample_vals):
        pred_cls = rf_pipe.predict(np.array([sample_vals]))[0]
        probs = rf_pipe.predict_proba(np.array([sample_vals]))[0]
        ph, do, turb, temp, cond = sample_vals
        reasons = []
        if pred_cls == 'Poor':
            if do < 4.5: reasons.append(f"severely depressed dissolved oxygen ({do} mg/L)")
            if turb > 30.0: reasons.append(f"excessive turbidity ({turb} NTU)")
            if ph < 6.0 or ph > 9.0: reasons.append(f"extreme pH ({ph})")
            if cond > 800.0: reasons.append(f"elevated conductivity ({cond} µS/cm)")
            if temp > 28.0: reasons.append(f"thermal stress ({temp} °C)")
        elif pred_cls == 'Moderate':
            if 4.5 <= do < 6.5: reasons.append(f"mildly sub-optimal dissolved oxygen ({do} mg/L)")
            if 10.0 < turb <= 30.0: reasons.append(f"moderate sediment loading ({turb} NTU)")
            if 250.0 < cond <= 800.0: reasons.append(f"moderate mineralization ({cond} µS/cm)")
        else:
            reasons.append("all five parameters satisfy pristine baseline standards")
        return f"Predicted {pred_cls.upper()} ({max(probs)*100:.1f}% confidence): " + ", ".join(reasons)

    print("\nPlain-Language Decision-Support Translations:")
    for idx in [0, 5, 10]:
        print(f"  Sample {idx}: {explain_prediction(X_test[idx])}")
    print("=" * 60)

if __name__ == '__main__':
    run()
