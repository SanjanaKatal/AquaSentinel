"""
AquaSentinel - AI-Based Water Quality Assessment and Pollution Risk Prediction System
Streamlit Dashboard for Decision Support and Screening (SDG 6)
"""

import os
import json
import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

st.set_page_config(
    page_title="AquaSentinel | Water Quality & Risk Prediction",
    page_icon="💧",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    /* Global Typography & Colors */
    :root {
        --primary-teal: #007A78;
        --secondary-cyan: #3AAFA9;
        --dark-marine: #17252A;
        --soft-bg: #F4F9F9;
        --card-bg: #FFFFFF;
        --warning-orange: #E67E22;
        --danger-red: #C0392B;
        --success-green: #27AE60;
    }
    
    .main-title {
        color: #007A78;
        font-size: 2.2rem;
        font-weight: 700;
        margin-bottom: 0.2rem;
    }
    .sub-title {
        color: #4A6572;
        font-size: 1.05rem;
        margin-bottom: 1.5rem;
    }
    .disclaimer-box {
        background-color: #FFF3CD;
        border-left: 5px solid #FFC107;
        padding: 0.9rem 1.2rem;
        border-radius: 4px;
        color: #856404;
        font-size: 0.88rem;
        margin-bottom: 1.5rem;
    }
    .kpi-card {
        background: #FFFFFF;
        border: 1px solid #E1E8ED;
        border-radius: 8px;
        padding: 1.1rem;
        box-shadow: 0 2px 4px rgba(0,0,0,0.04);
        text-align: center;
    }
    .kpi-value {
        font-size: 1.8rem;
        font-weight: 700;
        color: #007A78;
    }
    .kpi-label {
        font-size: 0.85rem;
        color: #555555;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 12px;
    }
    .stTabs [data-baseweb="tab"] {
        background-color: #EBF3F5;
        border-radius: 6px 6px 0px 0px;
        padding: 8px 16px;
    }
</style>
""", unsafe_allow_html=True)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs")
MODELS_DIR = os.path.join(BASE_DIR, "models")
REPORTS_DIR = os.path.join(BASE_DIR, "reports")

CLEANED_DATA_PATH = os.path.join(OUTPUTS_DIR, "cleaned_dataset.csv")
ANOMALY_DATA_PATH = os.path.join(OUTPUTS_DIR, "anomaly_results.csv")
METRICS_JSON_PATH = os.path.join(REPORTS_DIR, "model_results", "metrics_comparison.json")
METRICS_CSV_PATH = os.path.join(REPORTS_DIR, "model_results", "metrics_comparison.csv")

FEATURE_COLS = [
    'pH',
    'DissolvedOxygen_mgL',
    'Turbidity_NTU',
    'Temperature_C',
    'SpecificConductance_uScm'
]

FEATURE_LABELS = {
    'pH': 'pH (0-14)',
    'DissolvedOxygen_mgL': 'Dissolved Oxygen (mg/L)',
    'Turbidity_NTU': 'Turbidity (NTU)',
    'Temperature_C': 'Water Temperature (°C)',
    'SpecificConductance_uScm': 'Specific Conductance (µS/cm @ 25°C)'
}

PARAM_RANGES = {
    'pH': (0.0, 14.0, 7.2, 0.1),
    'DissolvedOxygen_mgL': (0.0, 20.0, 7.5, 0.1),
    'Turbidity_NTU': (0.0, 500.0, 8.0, 0.5),
    'Temperature_C': (0.0, 40.0, 18.0, 0.5),
    'SpecificConductance_uScm': (0.0, 10000.0, 180.0, 5.0)
}

CLASS_COLORS = {
    'Good': '#27AE60',
    'Moderate': '#F39C12',
    'Poor': '#C0392B'
}
@st.cache_data
def load_cleaned_data():
    if os.path.exists(CLEANED_DATA_PATH):
        df = pd.read_csv(CLEANED_DATA_PATH)
        if 'ActivityStartDate' in df.columns:
            df['ActivityStartDate'] = pd.to_datetime(df['ActivityStartDate'])
        return df
    return None

@st.cache_data
def load_anomaly_data():
    if os.path.exists(ANOMALY_DATA_PATH):
        return pd.read_csv(ANOMALY_DATA_PATH)
    return None

@st.cache_data
def load_metrics_data():
    if os.path.exists(METRICS_JSON_PATH):
        with open(METRICS_JSON_PATH, 'r') as f:
            return json.load(f)
    elif os.path.exists(METRICS_CSV_PATH):
        return pd.read_csv(METRICS_CSV_PATH).to_dict(orient='records')
    return None

@st.cache_resource
def load_models():
    models = {}
    model_files = {
        'Logistic Regression': 'logistic_regression.pkl',
        'Random Forest': 'random_forest.pkl',
        'XGBoost': 'xgboost_model.pkl',
        'Isolation Forest': 'isolation_forest.pkl'
    }
    for name, filename in model_files.items():
        path = os.path.join(MODELS_DIR, filename)
        if os.path.exists(path):
            try:
                models[name] = joblib.load(path)
            except Exception as e:
                st.sidebar.warning(f"Failed to load {name}: {e}")
    return models

st.sidebar.markdown("""
<div style="text-align: center; padding: 10px 0;">
    <span style="font-size: 3rem;">💧</span>
    <h2 style="color: #007A78; margin: 0;">AquaSentinel</h2>
    <p style="color: #555; font-size: 0.85rem; margin: 0;">AI Water Quality Decision Support</p>
</div>
""", unsafe_allow_html=True)
st.sidebar.caption("UN Sustainable Development Goal 6 (Clean Water)")

nav_selection = st.sidebar.radio(
    "Navigation Menu",
    [
        "1. Home / Overview",
        "2. Dataset Explorer",
        "3. Exploratory Data Analysis",
        "4. Water Quality Prediction",
        "5. Anomaly Detection Engine",
        "6. Model Benchmarking",
        "7. Explainable AI (SHAP)",
        "8. About & Limitations"
    ]
)

st.sidebar.markdown("---")
st.sidebar.info(
    "**System Status**: Decision-Support Prototype\n\n"
    "Data Source: Water Quality Portal (WQP / USGS / EPA)\n\n"
    "Region: North Carolina Basin (US:37)"
)

if nav_selection == "1. Home / Overview":
    st.markdown('<div class="main-title">💧 AquaSentinel: Sustainable Water Quality Management</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Screening and Decision-Support AI Prototype aligned with UN Sustainable Development Goal 6 (Clean Water and Sanitation)</div>', unsafe_allow_html=True)

    st.markdown("""
    <div class="disclaimer-box">
        <strong>⚠️ OPERATIONAL BOUNDARY & ETHICAL DISCLAIMER:</strong><br>
        AquaSentinel is an academic and investigative <em>decision-support prototype</em> for environmental screening and trend surveillance.
        It <strong>does NOT certify water as potable or safe</strong>, does not legally prove chemical pollution infractions,
        and must never supersede standard EPA / ISO certified laboratory assays.
    </div>
    """, unsafe_allow_html=True)

    # Load data for real KPIs
    df_clean = load_cleaned_data()
    metrics = load_metrics_data()
    df_anom = load_anomaly_data()

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        n_samples = len(df_clean) if df_clean is not None else "N/A"
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-value">{n_samples:,}</div>
            <div class="kpi-label">Physicochemical Samples</div>
        </div>
        """, unsafe_allow_html=True)
    with col2:
        n_stations = df_clean['MonitoringLocationIdentifier'].nunique() if df_clean is not None else "N/A"
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-value">{n_stations}</div>
            <div class="kpi-label">Monitoring Stations</div>
        </div>
        """, unsafe_allow_html=True)
    with col3:
        best_f1 = "N/A"
        if metrics:
            if isinstance(metrics, dict) and 'Random Forest' in metrics:
                best_f1 = f"{metrics['Random Forest'].get('macro_f1', 0)*100:.1f}%"
            elif isinstance(metrics, list) and len(metrics) > 0:
                best_f1 = f"{metrics[0].get('macro_f1', 0)*100:.1f}%"
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-value">{best_f1}</div>
            <div class="kpi-label">Best Model Macro F1</div>
        </div>
        """, unsafe_allow_html=True)
    with col4:
        n_anom = len(df_anom[df_anom['Anomaly_Label'] == 'Anomaly']) if df_anom is not None and 'Anomaly_Label' in df_anom.columns else "N/A"
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-value">{n_anom}</div>
            <div class="kpi-label">Flagged Sensor Anomalies</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("### 🌐 Core System Capabilities")
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown("""
        #### 📊 Standardized Data Ingestion
        * Programmatic ingestion of real-time monitoring records from **Water Quality Portal (WQP)**.
        * Standardized units: pH, Dissolved Oxygen ($mg/L$), Turbidity ($NTU$), Specific Conductance ($\mu S/cm$), Temperature ($°C$).
        * Rigorous deduplication and physical event sample-key alignment.
        """)
    with c2:
        st.markdown("""
        #### 🤖 Multi-Tier Classification
        * Benchmarked machine learning pipelines (**Logistic Regression, Random Forest, XGBoost**).
        * Group-aware station validation preventing spatial data leakage.
        * Prioritized optimization for **Recall of Impaired Waters** (minimizing dangerous false negatives).
        """)
    with c3:
        st.markdown("""
        #### 🔍 Explainable Diagnostics
        * Unsupervised **Isolation Forest** detecting multi-attribute sensor anomalies.
        * Robust Z-score explainability identifying parameter-level drivers.
        * Integrated **SHAP (SHapley Additive exPlanations)** attributing decision logic.
        """)

    st.markdown("---")
    st.markdown("### 🗺️ Geographic Coverage (USGS/STORET Stations)")
    if df_clean is not None and 'MonitoringLocationIdentifier' in df_clean.columns:
        station_summary = df_clean.groupby('MonitoringLocationIdentifier').size().reset_index(name='Observation_Count')
        top_stations = station_summary.sort_values(by='Observation_Count', ascending=False).head(10)
        fig_st = px.bar(
            top_stations,
            x='MonitoringLocationIdentifier',
            y='Observation_Count',
            title="Top 10 Active Surface Water Monitoring Stations in Dataset",
            color='Observation_Count',
            color_continuous_scale='Teal'
        )
        fig_st.update_layout(xaxis_tickangle=-45, height=380, margin=dict(l=20, r=20, t=40, b=80))
        st.plotly_chart(fig_st, use_container_width=True)

elif nav_selection == "2. Dataset Explorer":
    st.markdown('<div class="main-title">📁 Dataset Explorer & Filtering</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Inspect cleaned, standardized, and standards-labeled water monitoring data</div>', unsafe_allow_html=True)

    df_clean = load_cleaned_data()
    if df_clean is None:
        st.error(f"Cleaned dataset not found at `{CLEANED_DATA_PATH}`. Please execute the notebook pipeline first.")
    else:
        st.markdown("#### Filter Records")
        fc1, fc2, fc3 = st.columns(3)
        with fc1:
            classes = ['All'] + sorted(list(df_clean['Quality_Class'].unique()))
            sel_class = st.selectbox("Filter by Quality Class", classes)
        with fc2:
            min_temp, max_temp = float(df_clean['Temperature_C'].min()), float(df_clean['Temperature_C'].max())
            sel_temp = st.slider("Temperature Range (°C)", min_temp, max_temp, (min_temp, max_temp))
        with fc3:
            min_do, max_do = float(df_clean['DissolvedOxygen_mgL'].min()), float(df_clean['DissolvedOxygen_mgL'].max())
            sel_do = st.slider("Dissolved Oxygen Range (mg/L)", min_do, max_do, (min_do, max_do))

        filtered_df = df_clean.copy()
        if sel_class != 'All':
            filtered_df = filtered_df[filtered_df['Quality_Class'] == sel_class]
        filtered_df = filtered_df[
            (filtered_df['Temperature_C'] >= sel_temp[0]) & (filtered_df['Temperature_C'] <= sel_temp[1]) &
            (filtered_df['DissolvedOxygen_mgL'] >= sel_do[0]) & (filtered_df['DissolvedOxygen_mgL'] <= sel_do[1])
        ]

        st.markdown(f"**Showing {len(filtered_df):,} of {len(df_clean):,} records**")
        st.dataframe(filtered_df.head(100), use_container_width=True)

        col_dl1, col_dl2 = st.columns(2)
        with col_dl1:
            csv_data = filtered_df.to_csv(index=False).encode('utf-8')
            st.download_button(
                label="📥 Download Filtered Dataset (CSV)",
                data=csv_data,
                file_name="aquasentinel_filtered_data.csv",
                mime="text/csv"
            )
        with col_dl2:
            st.caption("Data is formatted in physical sample wide format keyed by monitoring station and timestamp.")

        st.markdown("---")
        st.markdown("#### Summary Statistics")
        st.dataframe(filtered_df[FEATURE_COLS].describe().round(2).T, use_container_width=True)

elif nav_selection == "3. Exploratory Data Analysis":
    st.markdown('<div class="main-title">📈 Exploratory Data Analysis</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Statistical distributions, limnological relationships, and parameter correlations</div>', unsafe_allow_html=True)

    df_clean = load_cleaned_data()
    if df_clean is None:
        st.error("Cleaned dataset not found. Please execute the notebook pipeline.")
    else:
        tab1, tab2, tab3, tab4 = st.tabs(["Distributions & Boxplots", "Limnological Analysis (DO vs Temp)", "Correlation Heatmap", "Class Proportions"])

        with tab1:
            st.markdown("#### Parameter Distributions by Water Quality Tier")
            selected_param = st.selectbox("Select Parameter to Inspect", FEATURE_COLS, format_func=lambda x: FEATURE_LABELS[x])

            col_p1, col_p2 = st.columns(2)
            with col_p1:
                fig_hist = px.histogram(
                    df_clean,
                    x=selected_param,
                    color='Quality_Class',
                    color_discrete_map=CLASS_COLORS,
                    barmode='overlay',
                    marginal='box',
                    title=f"Histogram & Rug of {FEATURE_LABELS[selected_param]}"
                )
                fig_hist.update_layout(height=420)
                st.plotly_chart(fig_hist, use_container_width=True)
            with col_p2:
                fig_box = px.box(
                    df_clean,
                    x='Quality_Class',
                    y=selected_param,
                    color='Quality_Class',
                    color_discrete_map=CLASS_COLORS,
                    title=f"Boxplot of {FEATURE_LABELS[selected_param]} across Tiers"
                )
                fig_box.update_layout(height=420)
                st.plotly_chart(fig_box, use_container_width=True)

            st.caption(f"**Interpretation**: {selected_param} shows distinct regulatory partitioning across tiers, validating the standards-based segmentation.")

        with tab2:
            st.markdown("#### Dedicated Dissolved Oxygen vs. Water Temperature Limnological Dynamics")
            st.markdown("""
            *Limnological Principle*: Colder water has a higher physical saturation capacity for dissolved gases (Henry's Law).
            As water temperature increases, maximum dissolved oxygen solubility drops, which compounds biological oxygen demand stress in aquatic organisms.
            """)

            fig_scatter = px.scatter(
                df_clean,
                x='Temperature_C',
                y='DissolvedOxygen_mgL',
                color='Quality_Class',
                color_discrete_map=CLASS_COLORS,
                trendline='ols',
                title="Dissolved Oxygen (mg/L) vs. Water Temperature (°C) with OLS Trendline",
                labels={'Temperature_C': 'Water Temperature (°C)', 'DissolvedOxygen_mgL': 'Dissolved Oxygen (mg/L)'}
            )
            fig_scatter.update_layout(height=480)
            st.plotly_chart(fig_scatter, use_container_width=True)

            corr_val = df_clean['Temperature_C'].corr(df_clean['DissolvedOxygen_mgL'])
            st.info(f"**Observed Pearson Correlation Coefficient**: $r = {corr_val:.3f}$. The empirical data demonstrates a clear inverse relationship consistent with freshwater gas solubility curves.")

        with tab3:
            st.markdown("#### Physicochemical Correlation Matrix")
            corr_matrix = df_clean[FEATURE_COLS].corr().round(3)
            fig_heat = px.imshow(
                corr_matrix,
                text_auto=True,
                aspect="auto",
                color_continuous_scale="Viridis",
                title="Pearson Correlation Matrix (5 Primary Physicochemical Parameters)"
            )
            fig_heat.update_layout(height=450)
            st.plotly_chart(fig_heat, use_container_width=True)
            st.caption("Low collinearity between turbidity, conductivity, and pH indicates that each parameter conveys non-redundant environmental information.")

        with tab4:
            st.markdown("#### Class Balance Distribution")
            class_counts = df_clean['Quality_Class'].value_counts().reset_index()
            class_counts.columns = ['Quality_Class', 'Count']
            fig_pie = px.pie(
                class_counts,
                names='Quality_Class',
                values='Count',
                color='Quality_Class',
                color_discrete_map=CLASS_COLORS,
                hole=0.4,
                title="Class Breakdown (Standards-Based Derived Labels)"
            )
            fig_pie.update_layout(height=420)
            st.plotly_chart(fig_pie, use_container_width=True)

elif nav_selection == "4. Water Quality Prediction":
    st.markdown('<div class="main-title">🎯 Water Quality Assessment & Prediction</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Evaluate multi-class risk classification based on user-entered physical measurements</div>', unsafe_allow_html=True)

    models = load_models()
    clf_models = {k: v for k, v in models.items() if k != 'Isolation Forest'}

    if not clf_models:
        st.warning("No classification models found in `models/`. Please execute the notebook pipeline to train and save models.")
    else:
        st.markdown("#### 1. Input Physicochemical Parameters")
        st.markdown("Adjust the sliders or type values within the standard freshwater operational envelope:")

        ic1, ic2, ic3 = st.columns(3)
        with ic1:
            input_ph = st.number_input("pH (Standard Units)", min_value=0.0, max_value=14.0, value=7.3, step=0.1)
            input_temp = st.number_input("Water Temperature (°C)", min_value=-2.0, max_value=50.0, value=18.5, step=0.5)
        with ic2:
            input_do = st.number_input("Dissolved Oxygen (mg/L)", min_value=0.0, max_value=25.0, value=7.2, step=0.1)
            input_cond = st.number_input("Specific Conductance (µS/cm)", min_value=0.0, max_value=50000.0, value=120.0, step=10.0)
        with ic3:
            input_turb = st.number_input("Turbidity (NTU)", min_value=0.0, max_value=2000.0, value=6.5, step=0.5)
            sel_model_name = st.selectbox("Select ML Model", list(clf_models.keys()), index=1 if "Random Forest" in clf_models else 0)

        # Input Validation Alerts
        input_warnings = []
        if input_ph < 5.5 or input_ph > 9.5:
            input_warnings.append(f"pH value ({input_ph}) is outside typical freshwater standards (6.5 - 8.5).")
        if input_do < 3.0:
            input_warnings.append(f"Dissolved Oxygen ({input_do} mg/L) indicates severe aquatic hypoxia.")
        if input_turb > 100.0:
            input_warnings.append(f"Turbidity ({input_turb} NTU) indicates heavy sediment or runoff plumes.")
        if input_cond > 2000.0:
            input_warnings.append(f"Conductivity ({input_cond} µS/cm) indicates elevated mineral/saline content.")

        for w in input_warnings:
            st.warning(f"⚠️ {w}")

        if st.button("🔮 Assess Water Quality", type="primary"):
            user_features = np.array([[input_ph, input_do, input_turb, input_temp, input_cond]])
            model = clf_models[sel_model_name]

            # Model prediction
            try:
                pred_label = model.predict(user_features)[0]
                pred_proba = model.predict_proba(user_features)[0]
                classes = model.classes_

                st.markdown("---")
                st.markdown("#### Assessment Result")

                rc1, rc2 = st.columns([1, 2])
                with rc1:
                    badge_color = CLASS_COLORS.get(pred_label, "#4A6572")
                    st.markdown(f"""
                    <div style="background-color: {badge_color}; color: white; padding: 1.5rem; border-radius: 8px; text-align: center;">
                        <h3 style="margin:0; color:white;">Predicted Tier:</h3>
                        <h1 style="margin:0.2rem 0; font-size: 2.8rem; color:white;">{pred_label}</h1>
                        <p style="margin:0; font-size: 0.9rem;">Evaluated via {sel_model_name}</p>
                    </div>
                    """, unsafe_allow_html=True)

                with rc2:
                    df_proba = pd.DataFrame({
                        'Class': classes,
                        'Probability': pred_proba
                    })
                    fig_prob = px.bar(
                        df_proba,
                        x='Probability',
                        y='Class',
                        orientation='h',
                        color='Class',
                        color_discrete_map=CLASS_COLORS,
                        text=[f"{p*100:.1f}%" for p in pred_proba],
                        title="Class Membership Confidence Probabilities"
                    )
                    fig_prob.update_layout(xaxis_range=[0, 1], height=240, margin=dict(l=20, r=20, t=40, b=20))
                    st.plotly_chart(fig_prob, use_container_width=True)

                # Explanatory Rule Breakdown
                st.markdown("##### 📋 Regulatory Rule Cross-Check (Decision Support)")
                checks = [
                    ("pH (6.5 - 8.5)", "Pass" if 6.5 <= input_ph <= 8.5 else ("Warn" if 6.0 <= input_ph <= 9.0 else "Fail")),
                    ("DO (≥ 6.5 mg/L)", "Pass" if input_do >= 6.5 else ("Warn" if input_do >= 4.5 else "Fail")),
                    ("Turbidity (≤ 10 NTU)", "Pass" if input_turb <= 10.0 else ("Warn" if input_turb <= 30.0 else "Fail")),
                    ("Conductivity (≤ 250 µS/cm)", "Pass" if input_cond <= 250.0 else ("Warn" if input_cond <= 800.0 else "Fail")),
                    ("Temperature (≤ 22 °C)", "Pass" if input_temp <= 22.0 else ("Warn" if input_temp <= 28.0 else "Fail"))
                ]
                check_cols = st.columns(5)
                for idx, (lbl, status) in enumerate(checks):
                    with check_cols[idx]:
                        s_color = "#27AE60" if status == "Pass" else ("#F39C12" if status == "Warn" else "#C0392B")
                        st.markdown(f"""
                        <div style="border: 1px solid {s_color}; border-radius: 6px; padding: 8px; text-align: center;">
                            <small>{lbl}</small><br>
                            <strong style="color:{s_color}; font-size:1.1rem;">{status}</strong>
                        </div>
                        """, unsafe_allow_html=True)

            except Exception as e:
                st.error(f"Prediction failed: {e}")

elif nav_selection == "5. Anomaly Detection Engine":
    st.markdown('<div class="main-title">🚨 Unsupervised Anomaly Detection</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Isolation Forest engine flagging multivariate sensor deviations and unusual water conditions</div>', unsafe_allow_html=True)

    st.markdown("""
    <div class="disclaimer-box">
        <strong>📌 Limnological Note:</strong> An anomaly does NOT inherently signify toxic contamination.
        Deviations can stem from flash precipitation runoff, estuarine brackish mixing, natural seasonal turnover, or sensor calibration drift.
    </div>
    """, unsafe_allow_html=True)

    df_anom = load_anomaly_data()
    models = load_models()
    iso_forest = models.get('Isolation Forest')

    if df_anom is None:
        st.warning(f"Anomaly dataset not found at `{ANOMALY_DATA_PATH}`. Please run the notebook.")
    else:
        st.markdown("#### 1. Flagged Observations in Dataset")
        n_total = len(df_anom)
        n_flagged = len(df_anom[df_anom['Anomaly_Label'] == 'Anomaly'])
        pct_flagged = (n_flagged / n_total) * 100

        ac1, ac2, ac3 = st.columns(3)
        with ac1:
            st.metric("Total Records Inspected", f"{n_total:,}")
        with ac2:
            st.metric("Flagged Anomalies", f"{n_flagged:,}", f"{pct_flagged:.1f}% contamination")
        with ac3:
            st.metric("Algorithm", "Isolation Forest (Scaled)")

        # Anomaly score distribution
        fig_score = px.histogram(
            df_anom,
            x='Anomaly_Score',
            color='Anomaly_Label',
            color_discrete_map={'Normal': '#3AAFA9', 'Anomaly': '#C0392B'},
            nbins=40,
            title="Isolation Forest Anomaly Score Distribution (Negative = Outlier)"
        )
        fig_score.update_layout(height=360)
        st.plotly_chart(fig_score, use_container_width=True)

        st.markdown("#### Flagged Anomalies Table with Plain-Language Explanations")
        flagged_df = df_anom[df_anom['Anomaly_Label'] == 'Anomaly'].copy()
        display_cols = [c for c in ['MonitoringLocationIdentifier', 'ActivityStartDate', 'pH', 'DissolvedOxygen_mgL', 'Turbidity_NTU', 'Temperature_C', 'SpecificConductance_uScm', 'Anomaly_Reason'] if c in flagged_df.columns]
        st.dataframe(flagged_df[display_cols].head(50), use_container_width=True)

        st.markdown("---")
        st.markdown("#### 2. Test User Input for Sensor Anomaly")
        st.markdown("Check if a specific custom reading looks multivariate-anomalous relative to baseline water records:")
        u1, u2, u3, u4, u5 = st.columns(5)
        with u1: u_ph = st.number_input("pH", 0.0, 14.0, 7.0, key="ano_ph")
        with u2: u_do = st.number_input("DO (mg/L)", 0.0, 25.0, 7.0, key="ano_do")
        with u3: u_turb = st.number_input("Turbidity (NTU)", 0.0, 1000.0, 10.0, key="ano_turb")
        with u4: u_temp = st.number_input("Temp (°C)", -2.0, 45.0, 20.0, key="ano_temp")
        with u5: u_cond = st.number_input("Cond (µS/cm)", 0.0, 30000.0, 150.0, key="ano_cond")

        if st.button("🔍 Check For Anomaly", type="secondary"):
            if iso_forest:
                input_arr = np.array([[u_ph, u_do, u_turb, u_temp, u_cond]])
                raw_pred = iso_forest.predict(input_arr)[0]
                raw_score = iso_forest.score_samples(input_arr)[0]
                is_anom = raw_pred == -1

                status_text = "ANOMALY FLAGGED" if is_anom else "NORMAL PROFILE"
                box_bg = "#FDEDEC" if is_anom else "#EAFAF1"
                border_c = "#C0392B" if is_anom else "#27AE60"

                st.markdown(f"""
                <div style="background-color: {box_bg}; border: 2px solid {border_c}; padding: 1rem; border-radius: 6px; margin: 1rem 0;">
                    <h3 style="color: {border_c}; margin:0;">Status: {status_text}</h3>
                    <p style="margin: 0.3rem 0;">Isolation Forest Score: <strong>{raw_score:.4f}</strong> (threshold ~ -0.10)</p>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.warning("Isolation Forest model file not loaded.")

elif nav_selection == "6. Model Benchmarking":
    st.markdown('<div class="main-title">📊 Model Benchmarking & Performance Comparison</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Evaluation across Logistic Regression, Random Forest, and XGBoost on held-out test data</div>', unsafe_allow_html=True)

    metrics_data = load_metrics_data()
    if metrics_data is None:
        st.warning(f"Metrics results not found at `{METRICS_JSON_PATH}`. Please run the notebook.")
    else:
        # Convert metrics to table
        rows = []
        if isinstance(metrics_data, dict):
            for model_name, m in metrics_data.items():
                rows.append({
                    'Model': model_name,
                    'Accuracy': m.get('accuracy', 0),
                    'Macro Precision': m.get('macro_precision', 0),
                    'Macro Recall': m.get('macro_recall', 0),
                    'Macro F1': m.get('macro_f1', 0),
                    'Poor Class Recall': m.get('class_recall', {}).get('Poor', m.get('poor_recall', 0))
                })
        elif isinstance(metrics_data, list):
            rows = metrics_data

        df_metrics = pd.DataFrame(rows)
        for col in ['Accuracy', 'Macro Precision', 'Macro Recall', 'Macro F1', 'Poor Class Recall']:
            if col in df_metrics.columns:
                df_metrics[col] = pd.to_numeric(df_metrics[col]).round(4)

        st.markdown("#### Overall Metric Comparison Table")
        st.dataframe(df_metrics, use_container_width=True)

        st.markdown("#### Comparative Visualization")
        melted = df_metrics.melt(id_vars=['Model'], value_vars=['Accuracy', 'Macro Precision', 'Macro Recall', 'Macro F1', 'Poor Class Recall'], var_name='Metric', value_name='Score')

        fig_m = px.bar(
            melted,
            x='Model',
            y='Score',
            color='Metric',
            barmode='group',
            text=[f"{v:.2f}" for v in melted['Score']],
            title="Comparison of Performance Metrics Across Models"
        )
        fig_m.update_layout(yaxis_range=[0, 1.05], height=420)
        st.plotly_chart(fig_m, use_container_width=True)

        st.markdown("""
        #### 💡 Engineering Takeaway:
        * **Poor Class Recall** is prioritized to prevent false negatives in water quality surveillance.
        * Tree ensembles (Random Forest and XGBoost) effectively capture nonlinear threshold boundaries embedded in regulatory standards.
        """)

elif nav_selection == "7. Explainable AI (SHAP)":
    st.markdown('<div class="main-title">🧠 Explainable AI & Feature Attribution</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Understanding feature importance and decision drivers via Gini, Permutation, and SHAP</div>', unsafe_allow_html=True)

    models = load_models()
    rf = models.get('Random Forest')

    if rf is not None and hasattr(rf, 'named_steps'):
        try:
            clf_step = rf.named_steps['classifier']
            if hasattr(clf_step, 'feature_importances_'):
                importances = clf_step.feature_importances_
                df_imp = pd.DataFrame({
                    'Feature': [FEATURE_LABELS[c] for c in FEATURE_COLS],
                    'Importance': importances
                }).sort_values(by='Importance', ascending=True)

                fig_imp = px.bar(
                    df_imp,
                    x='Importance',
                    y='Feature',
                    orientation='h',
                    title="Random Forest Gini Feature Importance",
                    color='Importance',
                    color_continuous_scale='Teal'
                )
                fig_imp.update_layout(height=360)
                st.plotly_chart(fig_imp, use_container_width=True)
        except Exception as e:
            st.info(f"Could not extract feature importances: {e}")

    # Check for saved SHAP plot images
    shap_img_path = os.path.join(REPORTS_DIR, "visualizations", "shap_summary.png")
    perm_img_path = os.path.join(REPORTS_DIR, "visualizations", "permutation_importance.png")

    c_x1, c_x2 = st.columns(2)
    with c_x1:
        st.markdown("#### Permutation Importance")
        if os.path.exists(perm_img_path):
            st.image(perm_img_path, caption="Permutation Importance on Held-Out Test Set", use_container_width=True)
        else:
            st.info("Permutation importance plot will appear here once generated by the notebook.")
    with c_x2:
        st.markdown("#### SHAP Summary Plot")
        if os.path.exists(shap_img_path):
            st.image(shap_img_path, caption="SHAP Global Bee-swarm Distribution", use_container_width=True)
        else:
            st.info("SHAP summary plot will appear here once generated by the notebook.")

    st.markdown("""
    #### 🔎 Attribution Insights:
    * **Dissolved Oxygen** and **Specific Conductance** consistently exhibit high feature attribution, reflecting their critical role in regulatory criteria and aquatic respiration.
    * **Turbidity** provides high local attribution during episodic storm-runoff events.
    """)

elif nav_selection == "8. About & Limitations":
    st.markdown('<div class="main-title">ℹ️ About AquaSentinel & Project Audit</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Methodological integrity, scientific limits, and university project documentation</div>', unsafe_allow_html=True)

    st.markdown("""
    ### 🔬 Project Overview & Academic Domain
    * **Project Title**: AquaSentinel – AI-Based Water Quality Assessment and Pollution Risk Prediction System
    * **Academic Domain**: Data Science Foundation
    * **Target SDG**: UN Sustainable Development Goal 6 (Ensure availability and sustainable management of water and sanitation for all)
    
    ---
    ### ⚠️ Honest Methodological Limitations & Integrity
    
    1. **Derived Standards vs. Ground-Truth Safety**:
       * Real-world WQP sensor logs do not feature true biochemical laboratory potability labels.
       * The target classes (`Good`, `Moderate`, `Poor`) are derived via published multi-parameter guidelines (WHO / US EPA).
       * Consequently, machine learning models approximate the deterministic regulatory rule system rather than discovering latent biological safety.
       
    2. **Sensor Measurement vs. Chemical Assay**:
       * The 5 physical parameters (pH, DO, Turbidity, Temp, Conductance) provide rapid screening of bulk physical properties.
       * They **cannot detect** dissolved heavy metals (lead, arsenic), persistent pesticides (PFAS), microplastics, or microbial pathogens (*E. coli*, Giardia).
       
    3. **Geographic & Seasonal Specificity**:
       * The training dataset is derived from surface monitoring stations across North Carolina (US:37).
       * Geochemical baselines (such as natural mineral conductivity in coastal versus mountain basins) vary significantly across watersheds.
       
    4. **Prototype Operational Boundary**:
       * AquaSentinel is strictly a **decision-support and early-warning screening tool**.
       * It must never replace EPA / BIS / ISO certified analytical chemistry assays or legal regulatory inspections.
    """)

    st.markdown("---")
    st.caption("AquaSentinel Prototype © 2026. Built with Python, Scikit-Learn, XGBoost, SHAP, and Streamlit.")
